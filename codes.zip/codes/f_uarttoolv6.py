
import Tkinter
from Tkinter import *
import ttk
import tkFileDialog

import math
import threading
import time
import os
import serial

from functools import partial


# commands used during UART communication
#################################
# NO    commands                #
# 1     send the app size       #
# 2     send the code           #
# 3     close the connection    #
# 4     send next chunk         #
#################################


# global variable to indicate connection status
connection_status = 0
serial_object = None

# delay function in us
def delay_us(t):
    t = t * 1e-6
    time.sleep(t)
    return

# function to close the UART connection
def close_conn():
	print "closing connection..."
	try:
		serial_object.close()
		connection_status = 0
	except AttributeError:
		print "No connection to close."
	return

# function to close the application gui
def disconnect():
    close_conn()
    return

# function to disconnect and close gui
def close():
    close_conn()
    print "Closing application..."
    gui.quit()
    return

# function to send the size via UART
def send_size():
    print "sending application size..."
    count = 0
    while count < length:
        delay_us(100)
        asize = (app_size_string[length-count-1])
        print "size char = ",asize
        serial_object.write(asize.encode())
        count += 1
    while count < 4:
        delay_us(100)
        serial_object.write('0')
        count += 1
    return

# function to read command via UART
def read_command():
	print "reading command"
	recvd_comm = serial_object.read(1)
	print "command =",recvd_comm
	return recvd_comm

#function to send selected image via UART
def send_app_img():
    print "sending application image..."
    sent_chunks = 0
    chunk_sent = 0
    chunk_size = 32
    #byte_count = 0
    while sent_chunks < app_size_chunks:
        byte_count = 0
        while byte_count < chunk_size: 
            byte = file.read(1)
            if byte != "":
                delay_us(100)
                serial_object.write(byte)
            else:
                delay_us(100)
                serial_object.write(hex('FF'))
            byte_count+=1
        recvd_comm = read_command()
        if recvd_comm == '4':
            chunk_sent = 1
            print "chunk",sent_chunks,"sent"
        else:
            chunk_sent = 0
            print "error in sending chunk",sent_chunks
            break
        sent_chunks+=1
    return chunk_sent

# function calls another function to send image and prints status
def send_app():
    success = send_app_img()
    if success == 1:
        print "application image sent successfully."
    else:
        print "error occurred in sending application image."
        close_conn()
        disconnect()
    return

# switch state according to received command
def state_switch(recvd_comm):
	if recvd_comm == '1':
		send_size()
	elif recvd_comm == '2':
		send_app()
	elif recvd_comm == '3':
		close_conn()
	else:
		close_conn()

#   switcher = {
#        1 : send_size(),      # send the size
#        2 : send_app(),       # send the code 
#        3 : close_conn()      # close the connection
#    }
#   Get the function from switcher dictionary
#   func = switcher.get(recvd_comm, "errorincommand")
#   Execute the function
	return

# state machine
def state_machine():
	#print "state machine"
	while connection_status == 1:
		recvd_comm = read_command()
		state_switch(recvd_comm)
	return

# function to convert each nibble in size in hex to char 
def size_as_string(app_size):
    size1 = hex(app_size).split('x')[-1]
    #print size1
    bytes_object = bytes(size1)
    ascii_string = bytes_object.decode("ASCII")
    #print ascii_string
    length = len(ascii_string)
    return ascii_string, length

# connect function 
# gets the baud rate and port
# connect serially 
def connect():
    # get the os name - windows or linux 
    os_name = button_var.get()
    port    = port_entry.get()
    baud    = baud_entry.get() 
    #print "OS -", os_name
    global connection_status
    global serial_object

    try:
        if os_name == 2:
            serial_object = serial.Serial('/dev/tty' + str(port), baud)
        elif os_name == 1:
            serial_object = serial.Serial('COM' + str(port), baud)  
        connection_status = 1
        print "Device connection successfull."
        delay_us(100)
        t1 = threading.Thread(target = state_machine)
    	t1.daemon = True
    	t1.start()
        #state_machine()  
    except ValueError:
        print "Enter Baud and Port"
    return

# function to browse file
# gets the filename, calculate its size
def browsefile():
    global filepath
    global file
    global app_size
    global app_size_chunks
    global app_size_string
    global length
    filepath = tkFileDialog.askopenfilename(filetypes = (("Template files", "*.type"), ("All files", "*")))
    # calculate file size and store it in global var
    file_stats = os.stat(filepath)
    app_size = file_stats.st_size
    print "application size =",app_size
    app_size_chunks = math.ceil(app_size / 32)
    print "application chunks =",app_size_chunks
    app_size_chunks = int(app_size_chunks)
    print "application chunks (int) =",app_size_chunks
    app_size_string, length = size_as_string(app_size_chunks)
    print "application chunks (hex) =",app_size_string
    file = open(filepath,"rb")
    print filepath
    return

#############################################################################################################
#                                            GUI                                                            #
#############################################################################################################

# create gui object
gui = Tk()
gui.title("UART Interface")
filename = ""
browsefilepath = "select file to be sent"

linebreak = 30
line = 0

if __name__ == "__main__":

    #frames
    #frame_1 = Frame(height = 285, width = 480, bd = 3, relief = 'groove').place(x = 7, y = 5)
    frame_2 = Frame(height = 200, width = 480, bd = 3, relief = 'groove').place(x = 7, y = 5)
    text = Text(width = 65, height = 5)

    # tool name at the top
    contact = Label(text = "UART TOOL").place(x = 350, y = line)

    line += linebreak
    #insert file browse option
    file_path_entry = Entry(gui, width = 30, text = browsefilepath, fg = 'grey')
    file_path_entry.place(x = 20, y = line)
    file_path_entry.insert(10, browsefilepath)
    #browsefile = partial(browsefile, browsefilepath)
    Button(text = "Browse", command = browsefile).place(x = 280, y = line)

    line += linebreak+10
    # label place -- baud rate
    baud   = Label(text = "Baud").place(x = 20, y = line)
    # data entry for baud rate and port 
    baud_entry = Entry(width = 10)
    baud_entry.place(x = 80, y = line)

    line += linebreak
    # label place -- port
    port   = Label(text = "Port").place(x = 20, y = line)
    port_entry = Entry(width = 10)
    port_entry.place(x = 80, y = line)

    line += linebreak
    #radio button
    button_var = IntVar()
    radio_1 = Radiobutton(text = "Windows", variable = button_var, value = 1).place(x = 20, y = line)
    radio_2 = Radiobutton(text = "Linux", variable = button_var, value = 2).place(x = 100, y = line)

    line += linebreak
    # connect and disconnect buttons
    connect = Button(text = "Connect", command = connect).place(x = 20, y = line)
    disconnect = Button(text = "Disconnect", command = disconnect).place(x =120, y = line)
    close = Button(text = "Close", command = close).place(x =240, y = line)

    #mainloop
    gui.geometry('500x220')
    gui.mainloop()
    #print "this is pawan"


